// Leichter, lizenzsicherer Start: iTunes Search API (30s Preview)
export async function searchItunesTracks(query, { country = "DE" } = {}) {
  if (!query?.trim()) return [];
  const url = `https://itunes.apple.com/search?term=${encodeURIComponent(query)}&entity=song&limit=25&country=${country}&lang=de_de`;
  const res = await fetch(url);
  if (!res.ok) return [];
  const data = await res.json();
  return (data.results || []).map(r => ({
    id: `itunes:${r.trackId}`,
    title: r.trackName,
    artist: r.artistName,
    album: r.collectionName,
    cover: (r.artworkUrl100 || "").replace("100x100bb", "512x512bb"),
    mp3: r.previewUrl,              // 30s MP3
    duration: Math.round((r.trackTimeMillis || 0) / 1000),
    href: r.trackViewUrl,           // Link zu Apple Music / iTunes
    source: { type: "itunes", raw: r }
  }));
}