// src/state/TrackContext.jsx
import { createContext, useContext, useEffect, useMemo, useRef, useState } from "react";
import { allTracks } from "../data/tracks";

const TrackContext = createContext(null);

export function TrackProvider({ children }) {
  const [index, setIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.25);

  const audioRef = useRef(null);
  const shouldAutoplayNextRef = useRef(false);
  // aktueller Track aus Playlist
  const track = allTracks[index];

  // Audio-Element einmalig erzeugen
  if (!audioRef.current) {
    audioRef.current = new Audio(track.audioUrl);
    audioRef.current.preload = "metadata";
    audioRef.current.volume = volume;
  }
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = Math.min(Math.max(volume, 0), 1);
    }
  }, [volume]);

  // Wenn Track wechselt: src setzen + ggf. weiterspielen
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    const wasPlaying = !audio.paused;
    audio.src = track.audioUrl;
    audio.load();
    setTime(0);
    setDuration(0);
    const shouldAuto = wasPlaying || shouldAutoplayNextRef.current;
    if (shouldAuto) {
      audio.play().catch(() => setIsPlaying(false));
    }
    // reset the one-shot flag after handling
    shouldAutoplayNextRef.current = false;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [index]);

  // Events verdrahten (timeupdate etc.)
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const onTime = () => setTime(audio.currentTime || 0);
    const onLoaded = () => setDuration(audio.duration || 0);
    const onEnded = () => {
      // mark that we should continue playing on the next track
      shouldAutoplayNextRef.current = true;
      next();
    };

    audio.addEventListener("timeupdate", onTime);
    audio.addEventListener("loadedmetadata", onLoaded);
    audio.addEventListener("ended", onEnded);

    return () => {
      audio.removeEventListener("timeupdate", onTime);
      audio.removeEventListener("loadedmetadata", onLoaded);
      audio.removeEventListener("ended", onEnded);
    };
  }, []);

  // Steuerfunktionen
  const play = async () => {
    try {
      await audioRef.current.play();
      setIsPlaying(true);
    } catch {
      setIsPlaying(false);
    }
  };
  const pause = () => {
    audioRef.current.pause();
    setIsPlaying(false);
  };
  const toggle = () => (isPlaying ? pause() : play());

  const seekSeconds = (sec) => {
    const a = audioRef.current;
    if (!a || !Number.isFinite(sec)) return;
    a.currentTime = Math.max(0, Math.min(sec, a.duration || sec));
    setTime(a.currentTime);
  };

  const next = () => {
    const n = allTracks.length;
    if (n <= 1) return;
    setIndex((i) => (i + 1) % n);
  };

  const prev = () => {
    const a = audioRef.current;
    if (a && a.currentTime > 3) {
      // zuerst auf Anfang springen
      seekSeconds(0);
      return;
    }
    const n = allTracks.length;
    if (n <= 1) return;
    setIndex((i) => (i - 1 + n) % n);
  };

  // Beim Play-Status Wechsel Audio pausieren/fortsetzen
  useEffect(() => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.play().catch(() => setIsPlaying(false));
    } else {
      audioRef.current.pause();
    }
  }, [isPlaying]);

  const progress = duration ? Math.min(1, time / duration) : 0;

  const value = useMemo(
    () => ({
      track,
      index,
      setIndex,
      isPlaying,
      setIsPlaying,
      time,
      duration,
      progress,
      volume,
      setVolume,
      play,
      pause,
      toggle,
      next,
      prev,
      seekSeconds,
    }),
    [track, index, isPlaying, time, duration, progress, volume]
  );

  return <TrackContext.Provider value={value}>{children}</TrackContext.Provider>;
}

export function useTrack() {
  const ctx = useContext(TrackContext);
  if (!ctx) throw new Error("useTrack must be used within <TrackProvider>");
  return ctx;
}